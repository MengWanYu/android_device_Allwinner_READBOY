#
# Copyright (C) 2026 The Android Open Source Project
#
# SPDX-License-Identifier: Apache-2.0
#
# Android device tree for Allwinner Readboy_G60 (READBOY)

Generated automatically using TWRP Device Tree Generator
this tool Developed by [Melek Saidani](https://www.facebook.com/no.idea.120/)

Arch: arm64-v8a
Manufacturer: Allwinner
Model: Readboy_G60

