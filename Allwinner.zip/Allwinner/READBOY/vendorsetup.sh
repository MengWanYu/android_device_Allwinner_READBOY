#
# Copyright (C) 2026 The Android Open Source Project
#
# SPDX-License-Identifier: Apache-2.0
#
add_lunch_combo omni_READBOY-user
add_lunch_combo omni_READBOY-userdebug
add_lunch_combo omni_READBOY-eng

